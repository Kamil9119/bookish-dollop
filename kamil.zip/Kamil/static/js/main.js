document.addEventListener('DOMContentLoaded', () => {
    const numberList = document.getElementById('number-list');
    const smsList = document.getElementById('sms-list');
    const selectedNumberSpan = document.getElementById('selected-number');
    let selectedNumber = null;

    // Fetch available numbers
    fetch('/api/numbers')
        .then(response => response.json())
        .then(numbers => {
            numbers.forEach(number => {
                const li = document.createElement('li');
                li.className = 'list-group-item';
                li.textContent = number;
                li.addEventListener('click', () => selectNumber(number));
                numberList.appendChild(li);
            });
        });

    // Select a number and fetch its SMS
    function selectNumber(number) {
        selectedNumber = number;
        selectedNumberSpan.textContent = number;
        smsList.innerHTML = '';
        fetchSMS(number);
    }

    // Fetch SMS for a number
    function fetchSMS(number) {
        fetch(`/api/sms/${number}`)
            .then(response => response.json())
            .then(smsMessages => {
                smsList.innerHTML = '';
                smsMessages.forEach(sms => {
                    const li = document.createElement('div');
                    li.className = 'list-group-item';
                    li.textContent = sms;
                    smsList.appendChild(li);
                });
            });
    }

    // Periodically refresh SMS for selected number
    setInterval(() => {
        if (selectedNumber) {
            fetchSMS(selectedNumber);
        }
    }, 5000); // Refresh every 5 seconds
});